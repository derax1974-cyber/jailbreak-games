import Nav from "./components/Nav";
import Hero from "./components/Hero";
import Marquee from "./components/Marquee";
import Compatibility from "./components/Compatibility";
import Services from "./components/Services";
import Process from "./components/Process";
import Lab from "./components/Lab";
import Pricing from "./components/Pricing";
import Testimonials from "./components/Testimonials";
import FAQ from "./components/FAQ";
import Contact from "./components/Contact";
import Footer from "./components/Footer";
import WhatsAppFab from "./components/WhatsAppFab";
import CustomCursor from "./components/fx/CustomCursor";
import Particles from "./components/fx/Particles";

export default function App() {
  return (
    <div className="relative min-h-screen bg-void font-sans text-white antialiased">
      {/* global backdrop */}
      <div className="bg-grid pointer-events-none fixed inset-0 z-0" />
      <Particles className="fixed inset-0 z-0 opacity-80" />
      <div className="noise" aria-hidden />

      <CustomCursor />
      <Nav />

      <main className="relative z-10">
        <Hero />
        <Marquee />
        <Compatibility />
        <Services />
        <Process />
        <Lab />
        <Marquee variant="accent" tilt />
        <Pricing />
        <Testimonials />
        <FAQ />
        <Contact />
      </main>

      <Footer />
      <WhatsAppFab />
    </div>
  );
}
