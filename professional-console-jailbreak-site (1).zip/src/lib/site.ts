export const CONTACT = {
  whatsappDisplay: "+56 9 6452 5882",
  whatsappNumber: "56964525882",
  email: "SERVICIOTECNICODRHOUSE2026@proton.me",
  hours: "Lun – Sáb · 9:00 – 21:00 (GMT-4)",
  coverage: "Remoto en todo LATAM & España",
};

export function waLink(message: string) {
  return `https://wa.me/${CONTACT.whatsappNumber}?text=${encodeURIComponent(message)}`;
}

export const WA_DEFAULT = waLink(
  "Hola NEXUS, quiero el diagnóstico gratuito para mi consola (PS4/PS5)."
);
