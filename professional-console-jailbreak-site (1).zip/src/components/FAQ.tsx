import { useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { Plus } from "lucide-react";
import { cn } from "../utils/cn";
import SectionHeader from "./SectionHeader";
import { Reveal } from "./fx/Reveal";

const QA: Array<{ q: string; a: string }> = [
  {
    q: "¿El desbloqueo puede dañar o «brickear» mi consola?",
    a: "No. Nuestro protocolo se ejecuta sobre el software, sin modificaciones destructivas de hardware. Antes de empezar verificamos placa, serial y estado físico; después, tres arranques consecutivos documentados en video. Más de 2,500 unidades atendidas y cero consolas dañadas.",
  },
  {
    q: "¿Puedo regresar al sistema original si algún día lo deseo?",
    a: "Sí. El proceso es completamente reversible. Puedes volver al firmware oficial de fábrica cuando quieras, y nosotros te guiamos gratis si tu garantía sigue activa. Tú sigues siendo dueño absoluto de tu consola.",
  },
  {
    q: "¿Qué firmwares soportan exactamente?",
    a: "PlayStation 4 hasta el firmware 13.52 (incluye 12.00, 12.50, 12.52, 13.00 y 13.02) y PlayStation 5 hasta el 13.60. Si tu consola tiene una versión superior, no te vamos a mentir: usa el verificador y te avisamos cuando exista un método estable.",
  },
  {
    q: "¿El servicio es remoto o debo llevar mi consola?",
    a: "Ambos. Ofrecemos servicio remoto asistido por videollamada en todo LATAM y España, o atención presencial con cita. En TODO caso firmamos un contrato técnico y documentamos el estado de tu unidad antes de empezar.",
  },
  {
    q: "¿Qué cubre la garantía?",
    a: "Cubre el 100% del trabajo realizado: arranque, estabilidad, panel de inicio y el escudo anti-actualizaciones. La duración depende del plan (3, 12 o 24 meses) y se entrega por escrito ligada al número de tu unidad. Si falla algo de lo que hicimos, lo reparamos sin costo.",
  },
  {
    q: "¿Es legal modificar mi propia consola?",
    a: "Modificar hardware y software de tu propiedad para uso personal es legal en la mayoría de los países de habla hispana. Nuestro servicio no incluye, distribuye ni promueve contenido protegido por derechos de autor: tu biblioteca y su uso son responsabilidad tuya.",
  },
];

export default function FAQ() {
  const [open, setOpen] = useState<number>(0);

  return (
    <section id="faq" className="relative py-28 sm:py-36">
      <div className="pointer-events-none absolute top-1/2 -left-32 h-[380px] w-[380px] rounded-full bg-violet/[0.06] blur-[120px]" />
      <div className="mx-auto max-w-5xl px-5 sm:px-8">
        <SectionHeader
          index="05"
          label="Preguntas frecuentes"
          align="center"
          title={
            <>
              Dudas <span className="grad-text">destruidas.</span>
            </>
          }
          desc="Las preguntas que todos hacen antes de entregar su consola, respondidas sin rodeos."
        />

        <div className="space-y-3">
          {QA.map((item, i) => {
            const isOpen = open === i;
            return (
              <Reveal key={i} delay={i * 50}>
                <div
                  className={cn(
                    "overflow-hidden rounded-2xl border transition-all duration-400",
                    isOpen ? "border-brand/35 bg-panel" : "border-line bg-panel/50 hover:border-white/20"
                  )}
                >
                  <button
                    onClick={() => setOpen(isOpen ? -1 : i)}
                    aria-expanded={isOpen}
                    className="flex w-full items-center gap-5 px-6 py-5 text-left sm:px-7"
                  >
                    <span className="font-mono text-[10px] tracking-[0.2em] text-white/30">
                      {String(i + 1).padStart(2, "0")}
                    </span>
                    <span className={cn("font-display flex-1 text-[15px] font-semibold sm:text-[17px]", isOpen ? "text-white" : "text-white/75")}>
                      {item.q}
                    </span>
                    <motion.span
                      animate={{ rotate: isOpen ? 45 : 0 }}
                      transition={{ duration: 0.35, ease: [0.22, 0.9, 0.24, 1] }}
                      className={cn(
                        "grid h-8 w-8 shrink-0 place-items-center rounded-full border transition-colors",
                        isOpen ? "border-brand/50 bg-brand-soft text-brand" : "border-white/15 text-white/40"
                      )}
                    >
                      <Plus size={15} />
                    </motion.span>
                  </button>
                  <AnimatePresence initial={false}>
                    {isOpen && (
                      <motion.div
                        initial={{ height: 0, opacity: 0 }}
                        animate={{ height: "auto", opacity: 1 }}
                        exit={{ height: 0, opacity: 0 }}
                        transition={{ duration: 0.45, ease: [0.22, 0.9, 0.24, 1] }}
                      >
                        <p className="px-6 pb-6 pl-[52px] text-[13.5px] leading-relaxed text-white/55 sm:px-7 sm:pl-[60px]">
                          {item.a}
                        </p>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>
              </Reveal>
            );
          })}
        </div>
      </div>
    </section>
  );
}
