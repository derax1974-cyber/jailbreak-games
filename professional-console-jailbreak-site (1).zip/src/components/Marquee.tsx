import { Fragment } from "react";
import { Sparkle } from "lucide-react";
import { cn } from "../utils/cn";

const ITEMS = [
  "PS4 · FW 13.52 / 13.02",
  "PS5 · FW 13.60",
  "Garantía escrita 12 meses",
  "Servicio remoto en LATAM",
  "Evidencia en video",
  "Diagnóstico gratuito",
  "Homebrew + emuladores",
  "Anti-actualizaciones",
];

export default function Marquee({
  className,
  tilt = false,
  variant = "dark",
}: {
  className?: string;
  tilt?: boolean;
  variant?: "dark" | "accent";
}) {
  const Row = () => (
    <>
      {ITEMS.map((item, i) => (
        <Fragment key={i}>
          <span className={cn("font-mono text-[11px] tracking-[0.3em] uppercase", variant === "accent" ? "text-[#032025]" : "text-white/60")}>
            {item}
          </span>
          <Sparkle size={11} className={cn("shrink-0", variant === "accent" ? "text-[#032025]/70" : "text-brand/70")} fill="currentColor" />
        </Fragment>
      ))}
    </>
  );

  return (
    <div
      className={cn(
        "relative overflow-hidden border-y py-4",
        variant === "accent" ? "border-transparent bg-brand" : "border-line bg-panel/60",
        tilt && "-rotate-[1.1deg] scale-[1.02]",
        className
      )}
    >
      <div className="marquee-track items-center gap-8 pr-8" style={{ ["--marquee-dur" as string]: "36s" }}>
        <Row />
        <Row />
      </div>
      <div className="pointer-events-none absolute inset-y-0 left-0 w-24 bg-gradient-to-r from-void to-transparent" style={{ display: variant === "accent" ? "none" : undefined }} />
      <div className="pointer-events-none absolute inset-y-0 right-0 w-24 bg-gradient-to-l from-void to-transparent" style={{ display: variant === "accent" ? "none" : undefined }} />
    </div>
  );
}
