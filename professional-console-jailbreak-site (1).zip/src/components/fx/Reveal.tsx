import { type ReactNode, type CSSProperties } from "react";
import { cn } from "../../utils/cn";
import { useInView } from "../../hooks/useInView";

type RevealProps = {
  children: ReactNode;
  className?: string;
  delay?: number;
  as?: "div" | "section" | "span" | "li" | "article";
};

export function Reveal({ children, className, delay = 0, as = "div" }: RevealProps) {
  const { ref, inView } = useInView<HTMLDivElement>(0.12);
  const Tag = as as "div";

  const style: CSSProperties = {
    opacity: inView ? 1 : 0,
    transform: inView ? "translateY(0px)" : "translateY(30px)",
    transition: `opacity 0.9s cubic-bezier(0.22,0.9,0.24,1) ${delay}ms, transform 0.9s cubic-bezier(0.22,0.9,0.24,1) ${delay}ms`,
    willChange: "opacity, transform",
  };

  return (
    <Tag ref={ref} className={cn(className)} style={style}>
      {children}
    </Tag>
  );
}
