import { useEffect, useRef } from "react";
import { cn } from "../../utils/cn";

type Particle = {
  x: number;
  y: number;
  vx: number;
  vy: number;
  r: number;
  a: number;
  hue: number;
  tw: number;
};

export default function Particles({ className }: { className?: string }) {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const reduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    const dpr = Math.min(window.devicePixelRatio || 1, 1.5);
    let w = 0;
    let h = 0;
    let raf = 0;
    let pts: Particle[] = [];
    let t = 0;
    const mouse = { x: -9999, y: -9999 };
    let hoverAmt = 0;

    const LINK = 125;

    const resize = () => {
      w = canvas.offsetWidth;
      h = canvas.offsetHeight;
      canvas.width = w * dpr;
      canvas.height = h * dpr;
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      const count = Math.min(110, Math.max(42, Math.floor((w * h) / 15000)));
      pts = Array.from({ length: count }, () => ({
        x: Math.random() * w,
        y: Math.random() * h,
        vx: (Math.random() - 0.5) * 0.28,
        vy: (Math.random() - 0.5) * 0.28,
        r: Math.random() * 1.6 + 0.5,
        a: Math.random() * 0.45 + 0.2,
        hue: Math.random() < 0.86 ? 187 : 318,
        tw: Math.random() * Math.PI * 2,
      }));
    };

    const onMove = (e: MouseEvent) => {
      const rect = canvas.getBoundingClientRect();
      mouse.x = e.clientX - rect.left;
      mouse.y = e.clientY - rect.top;
    };
    const onLeave = () => {
      mouse.x = -9999;
      mouse.y = -9999;
    };

    const draw = () => {
      t += 0.016;
      hoverAmt += ((mouse.x > -999 ? 1 : 0) - hoverAmt) * 0.05;
      ctx.clearRect(0, 0, w, h);

      for (const p of pts) {
        p.x += p.vx + Math.sin(t * 0.5 + p.tw) * 0.05;
        p.y += p.vy + Math.cos(t * 0.4 + p.tw) * 0.04;
        if (p.x < -20) p.x = w + 20;
        if (p.x > w + 20) p.x = -20;
        if (p.y < -20) p.y = h + 20;
        if (p.y > h + 20) p.y = -20;
      }

      for (let i = 0; i < pts.length; i++) {
        for (let j = i + 1; j < pts.length; j++) {
          const a = pts[i];
          const b = pts[j];
          const dx = a.x - b.x;
          const dy = a.y - b.y;
          const d2 = dx * dx + dy * dy;
          if (d2 < LINK * LINK) {
            const k = 1 - Math.sqrt(d2) / LINK;
            ctx.strokeStyle = `rgba(0, 210, 235, ${k * (0.1 + hoverAmt * 0.16)})`;
            ctx.lineWidth = 1;
            ctx.beginPath();
            ctx.moveTo(a.x, a.y);
            ctx.lineTo(b.x, b.y);
            ctx.stroke();
          }
        }
      }

      for (const p of pts) {
        const mdx = p.x - mouse.x;
        const mdy = p.y - mouse.y;
        const md = Math.sqrt(mdx * mdx + mdy * mdy);
        if (md < 150 && md > 0.01) {
          const f = ((150 - md) / 150) * 0.35;
          p.x += (mdx / md) * f;
          p.y += (mdy / md) * f;
        }
        const glow = p.a * (0.75 + Math.sin(t * 1.6 + p.tw) * 0.25);
        ctx.fillStyle = p.hue === 187 ? `rgba(0, 229, 255, ${glow})` : `rgba(255, 61, 129, ${glow * 0.8})`;
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
        ctx.fill();
      }

      if (mouse.x > -999) {
        const g = ctx.createRadialGradient(mouse.x, mouse.y, 0, mouse.x, mouse.y, 170);
        g.addColorStop(0, "rgba(0, 229, 255, 0.07)");
        g.addColorStop(1, "transparent");
        ctx.fillStyle = g;
        ctx.fillRect(mouse.x - 170, mouse.y - 170, 340, 340);
      }

      raf = requestAnimationFrame(draw);
    };

    resize();
    if (!reduced) {
      raf = requestAnimationFrame(draw);
    } else {
      for (const p of pts) {
        ctx.fillStyle = `rgba(0, 229, 255, ${p.a * 0.6})`;
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
        ctx.fill();
      }
    }

    window.addEventListener("resize", resize);
    window.addEventListener("mousemove", onMove, { passive: true });
    window.addEventListener("mouseout", onLeave);

    return () => {
      cancelAnimationFrame(raf);
      window.removeEventListener("resize", resize);
      window.removeEventListener("mousemove", onMove);
      window.removeEventListener("mouseout", onLeave);
    };
  }, []);

  return <canvas ref={canvasRef} className={cn("pointer-events-none", className)} aria-hidden />;
}
