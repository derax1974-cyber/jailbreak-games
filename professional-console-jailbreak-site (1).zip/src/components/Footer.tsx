import { ArrowUp, Terminal } from "lucide-react";
import { CONTACT, WA_DEFAULT } from "../lib/site";

const LINKS = [
  { href: "#compatibilidad", label: "Verificador" },
  { href: "#servicios", label: "Servicios" },
  { href: "#proceso", label: "Proceso" },
  { href: "#planes", label: "Planes" },
  { href: "#faq", label: "FAQ" },
];

export default function Footer() {
  return (
    <footer className="relative border-t border-line bg-[#04060a]">
      <div className="mx-auto max-w-7xl px-5 py-16 sm:px-8">
        <div className="grid gap-12 lg:grid-cols-[1.4fr_1fr_1fr_auto]">
          <div>
            <a href="#inicio" className="flex items-center gap-2.5">
              <span className="grid h-9 w-9 place-items-center rounded-lg border border-brand/40 bg-brand-soft text-brand">
                <Terminal size={16} strokeWidth={2.2} />
              </span>
              <span className="font-display text-[16px] font-bold tracking-wide text-white">
                NEXUS<span className="text-brand">_</span>UNLOCK
              </span>
            </a>
            <p className="mt-5 max-w-sm text-[13px] leading-relaxed text-white/40">
              Laboratorio técnico especializado en la liberación profesional de consolas PlayStation®.
              PS4 hasta FW 13.52 · PS5 hasta FW 13.60. Con expediente, evidencia y garantía real.
            </p>
            <p className="mt-6 font-mono text-[9.5px] tracking-[0.3em] text-white/25 uppercase">
              Operado por <span className="text-brand/70">Servicio Técnico Dr. House</span>
            </p>
            <p className="mt-2 font-mono text-[9.5px] tracking-[0.3em] text-white/25 uppercase">
              lat 00.00 · lon 00.00 — remotos a todas partes
            </p>
          </div>

          <div>
            <p className="kicker mb-5">Secciones</p>
            <ul className="space-y-3">
              {LINKS.map((l) => (
                <li key={l.href}>
                  <a href={l.href} className="text-[13px] text-white/45 transition-colors hover:text-brand">
                    {l.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <p className="kicker mb-5">Contacto</p>
            <ul className="space-y-3 text-[13px] text-white/45">
              <li>
                <a href={WA_DEFAULT} target="_blank" rel="noreferrer" className="transition-colors hover:text-brand">
                  WhatsApp {CONTACT.whatsappDisplay}
                </a>
              </li>
              <li>
                <a href={`mailto:${CONTACT.email}`} className="transition-colors hover:text-brand">
                  {CONTACT.email}
                </a>
              </li>
              <li>{CONTACT.hours}</li>
              <li>{CONTACT.coverage}</li>
            </ul>
          </div>

          <div className="flex flex-col items-start gap-4 lg:items-end">
            <a
              href="#inicio"
              aria-label="Volver arriba"
              className="group grid h-11 w-11 place-items-center rounded-full border border-white/15 text-white/60 transition-all duration-300 hover:border-brand hover:text-brand hover:shadow-[0_0_20px_rgba(0,229,255,.3)]"
            >
              <ArrowUp size={16} className="transition-transform duration-300 group-hover:-translate-y-0.5" />
            </a>
            <p className="font-mono text-[9.5px] tracking-[0.2em] text-white/25 uppercase lg:text-right">
              estado del sistema: <span className="text-emerald-400">online</span>
            </p>
          </div>
        </div>

        <div className="mt-14 border-t border-line pt-8">
          <p className="text-[11px] leading-relaxed text-white/30">
            NEXUS UNLOCK es un laboratorio técnico independiente. No está afiliado, patrocinado ni respaldado por Sony
            Interactive Entertainment. «PlayStation», «PS4» y «PS5» son marcas comerciales de Sony Interactive
            Entertainment Inc. El servicio se limita a modificaciones de software sobre hardware propiedad del
            cliente, destinadas al uso personal y legítimo de su consola. No se incluye, distribuye ni promueve
            ningún contenido protegido por derechos de autor.
          </p>
          <div className="mt-6 flex flex-wrap items-center justify-between gap-4">
            <p className="font-mono text-[10px] tracking-[0.2em] text-white/30 uppercase">
              © 2026 NEXUS UNLOCK — Todos los derechos reservados
            </p>
            <p className="font-mono text-[10px] tracking-[0.2em] text-white/30 uppercase">
              hecho con método · <span className="text-brand/70">no con prisa</span>
            </p>
          </div>
        </div>
      </div>
    </footer>
  );
}
