import type { ReactNode } from "react";
import { cn } from "../utils/cn";
import { Reveal } from "./fx/Reveal";

export default function SectionHeader({
  index,
  label,
  title,
  desc,
  align = "left",
  className,
}: {
  index: string;
  label: string;
  title?: ReactNode;
  desc?: ReactNode;
  align?: "left" | "center";
  className?: string;
}) {
  return (
    <div className={cn("relative mb-14 sm:mb-20", align === "center" && "text-center", className)}>
      <Reveal>
        <div className={cn("mb-5 flex items-center gap-4", align === "center" && "justify-center")}>
          <span className="font-mono text-[11px] tracking-[0.35em] text-brand">[ {index} ]</span>
          <span className="h-px w-14 bg-gradient-to-r from-brand/60 to-transparent" />
          <span className="kicker">{label}</span>
        </div>
      </Reveal>
      {title && (
        <Reveal delay={90}>
          <h2 className="font-display max-w-3xl text-4xl leading-[1.02] font-bold tracking-tight text-white sm:text-5xl lg:text-[3.5rem]">
            {title}
          </h2>
        </Reveal>
      )}
      {desc && (
        <Reveal delay={180}>
          <p className={cn("mt-5 max-w-xl text-[15px] leading-relaxed text-white/50", align === "center" && "mx-auto")}>{desc}</p>
        </Reveal>
      )}
    </div>
  );
}
