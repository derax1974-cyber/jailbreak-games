import { BadgeCheck, Quote, Star } from "lucide-react";
import SectionHeader from "./SectionHeader";
import { Reveal } from "./fx/Reveal";

type T = {
  name: string;
  init: string;
  place: string;
  unit: string;
  quote: string;
};

const DATA: T[] = [
  {
    name: "Carlos Mendoza",
    init: "CM",
    place: "Ciudad de México · MX",
    unit: "PS4 Pro · FW 13.52",
    quote:
      "Mi PS4 estaba en el último firmware y pensé que no había nada que hacer. En NEXUS me verificaron gratis el mismo día, y en 48 horas tenía la consola liberada con todo documentado. El video de pruebas me dio una confianza total.",
  },
  {
    name: "Valeria Ríos",
    init: "VR",
    place: "Guadalajara · MX",
    unit: "PS5 · FW 13.60",
    quote:
      "Atención humana de verdad: me explicaron cada paso por WhatsApp y me enviaron fotos del proceso. La consola arranca perfecta cada vez y el panel nuevo es rapidísimo. Recomendados con los ojos cerrados.",
  },
  {
    name: "Diego Torres",
    init: "DT",
    place: "Bogotá · CO",
    unit: "PS4 Slim · FW 13.02",
    quote:
      "Plan Pro: me instalaron el pack de emuladores y limpiaron la consola por dentro. Ahora hasta suena menos el ventilador. Se nota cuando la gente sabe lo que está haciendo.",
  },
  {
    name: "Andrés Salazar",
    init: "AS",
    place: "San Juan · PR",
    unit: "PS5 · FW 13.00",
    quote:
      "Lo hice todo remoto en una videollamada guiada. Minuciosos, pacientes y con garantía escrita de verdad. Nada que ver con los grupos de «hackeo» que andan por ahí.",
  },
];

export default function Testimonials() {
  return (
    <section id="opiniones" className="relative py-28 sm:py-36">
      <div className="mx-auto max-w-7xl px-5 sm:px-8">
        <SectionHeader
          index="04"
          label="Voz de clientes"
          title={
            <>
              Consolas liberadas.
              <br />
              <span className="text-stroke">Dueños convencidos.</span>
            </>
          }
          desc="Cada reseña va ligada a un número de unidad y un expediente real. Pedimos permiso para publicarlas, siempre."
        />

        <div className="grid gap-5 md:grid-cols-2">
          {DATA.map((t, i) => (
            <Reveal key={t.name} delay={(i % 2) * 110}>
              <figure className="glow-card group relative h-full rounded-2xl border border-line bg-panel/70 p-7 transition-all duration-500 hover:-translate-y-1 hover:border-brand/30 sm:p-8">
                <Quote size={80} className="absolute top-6 right-6 text-white/[0.045] transition-colors duration-500 group-hover:text-brand/10" />
                <div className="mb-5 flex items-center gap-1">
                  {Array.from({ length: 5 }).map((_, s) => (
                    <Star key={s} size={13} className="fill-brand text-brand" />
                  ))}
                </div>
                <blockquote className="relative text-[14px] leading-relaxed text-white/70">“{t.quote}”</blockquote>
                <figcaption className="mt-7 flex items-center gap-4 border-t border-line pt-6">
                  <span className="grid h-11 w-11 place-items-center rounded-full border border-brand/30 bg-brand-soft/40 font-display text-[13px] font-bold text-brand">
                    {t.init}
                  </span>
                  <div className="flex-1">
                    <p className="font-display text-[14px] font-bold text-white">{t.name}</p>
                    <p className="font-mono text-[9.5px] tracking-[0.16em] text-white/35 uppercase">{t.place}</p>
                  </div>
                  <span className="flex items-center gap-1.5 rounded-full border border-emerald-400/25 bg-emerald-400/[0.06] px-3 py-1.5 font-mono text-[9px] tracking-[0.12em] text-emerald-300/90 uppercase whitespace-nowrap">
                    <BadgeCheck size={11} /> {t.unit}
                  </span>
                </figcaption>
              </figure>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
