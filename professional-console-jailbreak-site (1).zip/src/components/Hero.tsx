import { useEffect, useMemo, useRef, useState } from "react";
import { motion, useScroll, useTransform, type MotionValue } from "framer-motion";
import {
  ArrowDown,
  ArrowUpRight,
  CheckCircle2,
  Cpu,
  Gamepad2,
  MessagesSquare,
  ShieldCheck,
  Zap,
} from "lucide-react";
import { cn } from "../utils/cn";

const ease = [0.22, 0.9, 0.24, 1] as const;

/* ---------------- scramble text ---------------- */
const GLYPHS = "ABCDEF0123456789#$%&/\\<>_";
function Scramble({ text, delay = 0 }: { text: string; delay?: number }) {
  const [out, setOut] = useState(text.replace(/\S/g, "·"));
  useEffect(() => {
    let frame = 0;
    let raf = 0;
    const total = 26;
    const start = performance.now() + delay;
    const tick = (now: number) => {
      if (now < start) {
        raf = requestAnimationFrame(tick);
        return;
      }
      frame++;
      const settled = Math.floor((frame / total) * text.length);
      let s = "";
      for (let i = 0; i < text.length; i++) {
        if (i < settled || text[i] === " ") s += text[i];
        else s += GLYPHS[Math.floor(Math.random() * GLYPHS.length)];
      }
      setOut(s);
      if (settled < text.length) raf = requestAnimationFrame(tick);
      else setOut(text);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [text, delay]);
  return <span className="whitespace-pre">{out}</span>;
}

/* ---------------- terminal ---------------- */
const BOOT: Array<{ t: string; ok?: boolean; accent?: boolean }> = [
  { t: "nexus@lab:~$ iniciar protocolo de desbloqueo" },
  { t: "→ consola detectada ... PS5 · FW 13.60" },
  { t: "→ handshake seguro", ok: true },
  { t: "→ cadena de exploit cargada · persistencia v7.2", ok: true },
  { t: "→ parche de kernel aplicado", ok: true },
  { t: "→ escudo anti-actualización activo", ok: true },
  { t: "→ verificación de arranque: 3/3", ok: true },
  { t: "▣ ESTADO: CONSOLA LIBERADA · GARANTÍA 12M", accent: true },
];

function Terminal({ start }: { start: boolean }) {
  const [lines, setLines] = useState<Array<{ t: string; ok?: boolean; accent?: boolean }>>([]);
  const [typing, setTyping] = useState("");
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!start) return;
    let line = 0;
    let char = 0;
    let timeout: ReturnType<typeof setTimeout>;
    let alive = true;

    const step = () => {
      if (!alive) return;
      if (line >= BOOT.length) {
        timeout = setTimeout(() => {
          if (!alive) return;
          setLines([]);
          setTyping("");
          line = 0;
          char = 0;
          step();
        }, 5200);
        return;
      }
      const cur = BOOT[line];
      char++;
      setTyping(cur.t.slice(0, char));
      if (char >= cur.t.length) {
        setLines((prev) => [...prev.slice(-5), cur]);
        setTyping("");
        line++;
        char = 0;
        timeout = setTimeout(step, cur.accent ? 700 : 330);
      } else {
        timeout = setTimeout(step, 16 + Math.random() * 24);
      }
    };
    timeout = setTimeout(step, 700);
    return () => {
      alive = false;
      clearTimeout(timeout);
    };
  }, [start]);

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight });
  }, [lines, typing]);

  return (
    <div className="overflow-hidden rounded-b-xl border-t border-line bg-[#05090f]/95 font-mono text-[10.5px] leading-[1.9] sm:text-[11px]">
      <div ref={scrollRef} className="h-[168px] overflow-hidden px-4 py-3 sm:h-[176px]">
        {lines.map((l, i) => (
          <p key={i} className={cn("whitespace-nowrap", l.accent ? "text-brand font-semibold" : l.ok ? "text-emerald-300/90" : "text-white/55")}>
            {l.ok ? <span className="text-emerald-400">[ OK ] </span> : null}
            {l.t.startsWith("→") || l.ok ? l.t.replace(/^→ /, "→ ") : l.t}
          </p>
        ))}
        {typing && (
          <p className="text-white/80 whitespace-nowrap">
            {typing}
            <span className="caret ml-0.5 inline-block h-[12px] w-[6px] translate-y-[2px] bg-brand" />
          </p>
        )}
        {!typing && lines.length >= BOOT.length && (
          <p className="text-white/35">
            <span className="caret ml-0.5 inline-block h-[12px] w-[6px] translate-y-[2px] bg-brand" />
          </p>
        )}
      </div>
    </div>
  );
}

/* ---------------- floating chip ---------------- */
function FloatChip({
  className,
  children,
  delay = 0,
  y,
}: {
  className?: string;
  children: React.ReactNode;
  delay?: number;
  y?: MotionValue<number>;
}) {
  return (
    <motion.div
      style={{ y }}
      initial={{ opacity: 0, scale: 0.8 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ delay, duration: 0.7, ease }}
      className={cn(
        "pointer-events-none absolute z-20 flex items-center gap-2 rounded-lg border border-line bg-panel/85 px-3 py-2 backdrop-blur-md shadow-[0_8px_30px_rgba(0,0,0,.45)]",
        className
      )}
    >
      {children}
    </motion.div>
  );
}

/* ---------------- stats ---------------- */
const STATS = [
  { v: 2500, suffix: "+", label: "Consolas liberadas" },
  { v: 99.8, suffix: "%", label: "Tasa de éxito", decimals: 1 },
  { v: 12, suffix: "M", label: "Garantía real" },
  { v: 15, suffix: "m", label: "Diagnóstico gratis" },
];

function Stat({ v, suffix, label, decimals = 0, delay = 0 }: { v: number; suffix: string; label: string; decimals?: number; delay?: number }) {
  const [n, setN] = useState(0);
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const obs = new IntersectionObserver(
      ([e]) => {
        if (!e.isIntersecting) return;
        obs.disconnect();
        const t0 = performance.now() + delay;
        const dur = 1600;
        const tick = (now: number) => {
          if (now < t0) return requestAnimationFrame(tick);
          const p = Math.min(1, (now - t0) / dur);
          const eased = 1 - Math.pow(1 - p, 4);
          setN(v * eased);
          if (p < 1) requestAnimationFrame(tick);
        };
        requestAnimationFrame(tick);
      },
      { threshold: 0.5 }
    );
    obs.observe(el);
    return () => obs.disconnect();
  }, [v, delay, decimals]);

  return (
    <div ref={ref} className="group">
      <p className="font-display text-[26px] font-bold text-white transition-colors duration-300 group-hover:text-brand sm:text-3xl">
        {n.toFixed(decimals)}
        <span className="text-brand">{suffix}</span>
      </p>
      <p className="mt-1 font-mono text-[9.5px] tracking-[0.22em] text-white/40 uppercase">{label}</p>
    </div>
  );
}

/* ---------------- hero ---------------- */
export default function Hero() {
  const raw = useScroll({ offset: ["start start", "end start"] });
  const y1 = useTransform(raw.scrollY, [0, 500], [0, -46]);
  const y2 = useTransform(raw.scrollY, [0, 500], [0, 60]);

  const headline = useMemo(
    () => [
      { text: "TU CONSOLA", stroke: false },
      { text: "TIENE UN MODO", stroke: false, gradient: true },
      { text: "OCULTO.", stroke: true },
    ],
    []
  );

  return (
    <section id="inicio" className="relative flex min-h-[100svh] flex-col overflow-hidden pt-[68px]">
      {/* ambient glows */}
      <div className="pointer-events-none absolute -top-40 left-1/2 h-[520px] w-[820px] -translate-x-1/2 rounded-full bg-brand/[0.07] blur-[120px]" />
      <div className="pointer-events-none absolute top-1/3 -left-40 h-[420px] w-[420px] rounded-full bg-violet/[0.09] blur-[110px]" />
      <div className="pointer-events-none absolute -right-40 bottom-0 h-[460px] w-[460px] rounded-full bg-mag/[0.06] blur-[120px]" />

      {/* side annotation */}
      <div className="pointer-events-none absolute top-1/2 right-6 hidden -translate-y-1/2 rotate-180 items-center gap-3 xl:flex" style={{ writingMode: "vertical-rl" }}>
        <span className="font-mono text-[9px] tracking-[0.5em] text-white/25 uppercase">Protocolo activo — laboratorio remoto · LatAm</span>
        <span className="h-16 w-px bg-gradient-to-b from-brand/50 to-transparent" />
      </div>
      <div className="pointer-events-none absolute top-1/2 left-6 hidden -translate-y-1/2 rotate-180 items-center gap-3 xl:flex" style={{ writingMode: "vertical-rl" }}>
        <span className="h-16 w-px bg-gradient-to-b from-brand/50 to-transparent" style={{ transform: "rotate(180deg)" }} />
        <span className="font-mono text-[9px] tracking-[0.5em] text-white/25 uppercase">FW 13.52 · FW 13.60 — Soporte verificado</span>
      </div>

      <div className="relative mx-auto grid w-full max-w-7xl flex-1 items-center gap-14 px-5 pt-14 pb-16 sm:px-8 lg:grid-cols-[1.05fr_0.95fr] lg:gap-8 lg:pt-8">
        {/* ------- left ------- */}
        <div className="relative z-10">
          <motion.div
            initial={{ opacity: 0, y: 14 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, ease }}
            className="mb-7 inline-flex items-center gap-3 rounded-full border border-brand/25 bg-brand-soft/40 py-1.5 pr-4 pl-1.5"
          >
            <span className="flex items-center gap-1.5 rounded-full bg-brand px-3 py-1 font-mono text-[9.5px] font-bold tracking-[0.18em] text-[#03222a] uppercase">
              <span className="pulse-dot inline-block h-1.5 w-1.5 rounded-full bg-[#03222a]" /> Live
            </span>
            <span className="font-mono text-[10.5px] tracking-[0.14em] text-white/75 uppercase">
              Soporte verificado · <span className="text-brand font-semibold">PS4 → 13.52</span> · <span className="text-brand font-semibold">PS5 → 13.60</span>
            </span>
          </motion.div>

          <h1 className="font-display text-[clamp(2.9rem,7.2vw,5.6rem)] leading-[0.98] font-bold tracking-tight text-white">
            {headline.map((line, i) => (
              <span key={i} className="line-mask block">
                <span
                  className="inner"
                  style={{ animationDelay: `${0.15 + i * 0.13}s` }}
                >
                  <span className={cn(line.stroke ? "text-stroke" : line.gradient ? "grad-text" : "")}>{line.text}</span>
                </span>
              </span>
            ))}
          </h1>

          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.75, duration: 0.8 }}
            className="mt-7 max-w-xl"
          >
            <p className="mb-3 font-mono text-[12px] text-brand/90">
              <Scramble text="> inicializando secuencia de liberación..." delay={900} />
            </p>
            <p className="text-[15px] leading-relaxed text-white/55 sm:text-base">
              Desbloqueo <span className="text-white/85 font-medium">profesional y documentado</span> para PlayStation 4
              hasta el firmware <span className="font-mono text-brand">13.52</span> y PlayStation 5 hasta{" "}
              <span className="font-mono text-brand">13.60</span>. Instalación de precisión, pruebas de estabilidad 3×,
              evidencia en video y <span className="text-white/85 font-medium">garantía escrita de 12 meses</span>.
            </p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 18 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.9, duration: 0.7, ease }}
            className="mt-9 flex flex-wrap items-center gap-4"
          >
            <a
              href="#contacto"
              className="btn-primary group inline-flex items-center gap-2.5 rounded-full bg-brand px-7 py-4 font-display text-[13px] font-bold tracking-[0.08em] text-[#03222a] uppercase transition-all duration-300 hover:shadow-[0_0_46px_rgba(0,229,255,.5)]"
            >
              <span className="relative z-[2] flex items-center gap-2.5">
                <Zap size={15} fill="currentColor" />
                Solicitar desbloqueo
                <ArrowUpRight size={15} className="transition-transform duration-300 group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
              </span>
            </a>
            <a
              href="#compatibilidad"
              className="group inline-flex items-center gap-2.5 rounded-full border border-white/15 px-7 py-4 font-display text-[13px] font-semibold tracking-[0.08em] text-white/85 uppercase transition-all duration-300 hover:border-brand/60 hover:text-brand"
            >
              <CheckCircle2 size={15} className="text-brand" />
              Verificar mi consola
            </a>
          </motion.div>

          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 1.15, duration: 0.9 }}
            className="mt-14 grid grid-cols-2 gap-x-6 gap-y-7 border-t border-line pt-7 sm:grid-cols-4"
          >
            {STATS.map((s, i) => (
              <Stat key={s.label} {...s} delay={i * 120} />
            ))}
          </motion.div>
        </div>

        {/* ------- right: visual ------- */}
        <motion.div
          initial={{ opacity: 0, y: 40, scale: 0.97 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          transition={{ delay: 0.45, duration: 1, ease }}
          className="relative"
        >
          <div className="hud-frame floaty">
            <span className="corner c-tl" /><span className="corner c-tr" /><span className="corner c-bl" /><span className="corner c-br" />

            {/* image */}
            <div className="relative overflow-hidden rounded-t-xl border border-line">
              <img
                src="/img/hero-consoles.jpg"
                alt="Consolas PlayStation con iluminación cian en laboratorio de desbloqueo"
                className="h-[300px] w-full object-cover sm:h-[360px] lg:h-[400px]"
                loading="eager"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#05090f] via-transparent to-transparent" />
              <div className="scanline" />

              {/* HUD tags on image */}
              <div className="absolute top-3 left-3 flex items-center gap-2 rounded-md border border-white/10 bg-black/50 px-2.5 py-1.5 font-mono text-[9.5px] tracking-[0.16em] text-white/80 uppercase backdrop-blur-sm">
                <Gamepad2 size={12} className="text-brand" /> PS5 · FW 13.60 <span className="text-emerald-400">unlocked</span>
              </div>
              <div className="absolute top-3 right-3 flex items-center gap-2 rounded-md border border-white/10 bg-black/50 px-2.5 py-1.5 font-mono text-[9.5px] tracking-[0.16em] text-white/80 uppercase backdrop-blur-sm">
                <Cpu size={12} className="text-brand" /> PS4 · FW 13.52 <span className="text-emerald-400">ready</span>
              </div>
              <div className="absolute bottom-3 left-3 font-mono text-[9px] tracking-[0.2em] text-white/40 uppercase">
                unidad_x90 // inspección de laboratorio · rec 00:14:26
              </div>
            </div>

            {/* terminal */}
            <Terminal start />
          </div>

          {/* floating chips */}
          <FloatChip className="-left-3 top-14 sm:-left-6" delay={1.15} y={y1}>
            <ShieldCheck size={14} className="text-emerald-400" />
            <div>
              <p className="font-mono text-[9px] tracking-[0.18em] text-white/45 uppercase">Integridad</p>
              <p className="font-display text-[12.5px] font-bold text-white">100% estable</p>
            </div>
          </FloatChip>
          <FloatChip className="right-1 -bottom-4 sm:-right-3 sm:-bottom-5" delay={1.35} y={y2}>
            <MessagesSquare size={14} className="text-brand" />
            <div>
              <p className="font-mono text-[9px] tracking-[0.18em] text-white/45 uppercase">Soporte humano</p>
              <p className="font-display text-[12.5px] font-bold text-white">Resp. &lt; 5 min</p>
            </div>
          </FloatChip>
        </motion.div>
      </div>

      {/* scroll cue */}
      <motion.a
        href="#compatibilidad"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1.8 }}
        className="group relative z-10 mx-auto mb-8 flex flex-col items-center gap-2"
        aria-label="Bajar a compatibilidad"
      >
        <span className="font-mono text-[9px] tracking-[0.4em] text-white/35 uppercase transition-colors group-hover:text-brand">Scroll</span>
        <motion.span animate={{ y: [0, 6, 0] }} transition={{ duration: 1.8, repeat: Infinity, ease: "easeInOut" }}>
          <ArrowDown size={14} className="text-brand" />
        </motion.span>
      </motion.a>
    </section>
  );
}
