import { FlaskConical, Camera, FileCheck2, Microscope, Recycle, Thermometer } from "lucide-react";
import SectionHeader from "./SectionHeader";
import { Reveal } from "./fx/Reveal";

const POINTS = [
  {
    icon: Microscope,
    title: "Placa y serial verificados",
    desc: "Antes de tocar nada: revisión física y registro escrito del estado de tu unidad.",
  },
  {
    icon: Thermometer,
    title: "Ambiente controlado",
    desc: "Estación de trabajo antiestática (ESD), temperatura regulada y herramientas de precisión.",
  },
  {
    icon: Camera,
    title: "Registro fotográfico total",
    desc: "Fotos y logs de cada fase. Recibes el expediente completo de lo que se hizo y por qué.",
  },
  {
    icon: FileCheck2,
    title: "Pruebas documentadas 3×",
    desc: "Tres arranques consecutivos + prueba de estrés en video antes de darte por entregada tu consola.",
  },
];

export default function Lab() {
  return (
    <section id="lab" className="relative py-28 sm:py-36">
      <div className="pointer-events-none absolute right-0 bottom-0 h-[420px] w-[420px] rounded-full bg-brand/[0.05] blur-[130px]" />
      <div className="mx-auto max-w-7xl px-5 sm:px-8">
        <SectionHeader
          index="LAB"
          label="Dentro del laboratorio"
          title={
            <>
              Laboratorio real.
              <br />
              <span className="grad-text">Método real.</span>
            </>
          }
          desc="Esto no es un «flasheo» improvisado de garaje. Es ingeniería aplicada sobre tu consola, con expediente y respaldo."
        />

        <div className="grid items-center gap-12 lg:grid-cols-2 lg:gap-16">
          {/* image */}
          <Reveal className="order-2 lg:order-1">
            <div className="hud-frame">
              <span className="corner c-tl" /><span className="corner c-tr" /><span className="corner c-bl" /><span className="corner c-br" />
              <div className="relative overflow-hidden rounded-2xl border border-line">
                <img
                  src="/img/lab-board.jpg"
                  alt="Placa madre de consola en estación de trabajo del laboratorio NEXUS"
                  className="h-[340px] w-full object-cover transition-transform duration-[1.4s] ease-out hover:scale-[1.04] sm:h-[420px]"
                  loading="lazy"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#05080d] via-transparent to-transparent" />
                <div className="scanline" />
                <div className="absolute top-3 left-3 flex items-center gap-2 rounded-md border border-white/10 bg-black/50 px-2.5 py-1.5 font-mono text-[9.5px] tracking-[0.16em] text-white/80 uppercase backdrop-blur-sm">
                  <FlaskConical size={12} className="text-brand" /> estación_02 · ESD
                </div>
                <div className="absolute right-3 bottom-3 left-3 flex items-end justify-between">
                  <p className="font-mono text-[9px] tracking-[0.2em] text-white/45 uppercase">
                    macro_placa // punto de inyección verificado
                  </p>
                  <p className="font-mono text-[11px] font-semibold text-brand">00 brickeos</p>
                </div>
              </div>
            </div>
          </Reveal>

          {/* points */}
          <div className="order-1 space-y-5 lg:order-2">
            {POINTS.map((p, i) => (
              <Reveal key={p.title} delay={i * 90}>
                <div className="group flex gap-5 rounded-2xl border border-line bg-panel/60 p-5 transition-all duration-400 hover:border-brand/30 hover:bg-panel sm:p-6">
                  <span className="grid h-11 w-11 shrink-0 place-items-center rounded-xl border border-brand/25 bg-brand-soft/40 text-brand transition-all duration-400 group-hover:shadow-[0_0_18px_rgba(0,229,255,.28)]">
                    <p.icon size={18} strokeWidth={1.8} />
                  </span>
                  <div>
                    <h3 className="font-display text-[15.5px] font-bold text-white">{p.title}</h3>
                    <p className="mt-1 text-[13px] leading-relaxed text-white/50">{p.desc}</p>
                  </div>
                </div>
              </Reveal>
            ))}
            <Reveal delay={380}>
              <div className="flex flex-wrap items-center gap-x-8 gap-y-3 border-t border-dashed border-line pt-6">
                <span className="font-mono text-[10px] tracking-[0.24em] text-white/35 uppercase">3× arranques verificados</span>
                <span className="font-mono text-[10px] tracking-[0.24em] text-white/35 uppercase">0 unidades dañadas</span>
                <span className="flex items-center gap-1.5 font-mono text-[10px] tracking-[0.24em] text-brand/80 uppercase">
                  <Recycle size={11} /> componentes reciclados
                </span>
              </div>
            </Reveal>
          </div>
        </div>
      </div>
    </section>
  );
}
