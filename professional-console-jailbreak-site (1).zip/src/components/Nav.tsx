import { useEffect, useState } from "react";
import { AnimatePresence, motion, useScroll, useSpring } from "framer-motion";
import { Menu, Terminal, X, ArrowUpRight } from "lucide-react";
import { cn } from "../utils/cn";

const LINKS = [
  { href: "#compatibilidad", label: "Compatibilidad" },
  { href: "#servicios", label: "Servicios" },
  { href: "#proceso", label: "Proceso" },
  { href: "#planes", label: "Planes" },
  { href: "#faq", label: "FAQ" },
];

export default function Nav() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);
  const [active, setActive] = useState("");
  const { scrollYProgress } = useScroll();
  const progress = useSpring(scrollYProgress, { stiffness: 120, damping: 26, mass: 0.4 });

  useEffect(() => {
    const onScroll = () => {
      setScrolled(window.scrollY > 30);
      const ids = LINKS.map((l) => l.href.slice(1));
      let current = "";
      for (const id of ids) {
        const el = document.getElementById(id);
        if (el && el.getBoundingClientRect().top < window.innerHeight * 0.4) current = id;
      }
      setActive(current);
    };
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    document.body.style.overflow = open ? "hidden" : "";
    return () => { document.body.style.overflow = ""; };
  }, [open]);

  return (
    <>
      <motion.div
        className="fixed top-0 left-0 z-[80] h-[2px] w-full origin-left bg-gradient-to-r from-brand via-violet to-brand"
        style={{ scaleX: progress }}
      />
      <header
        className={cn(
          "fixed top-0 left-0 z-[75] w-full transition-all duration-500",
          scrolled ? "bg-void/70 backdrop-blur-xl border-b border-line" : "bg-transparent border-b border-transparent"
        )}
      >
        <div className="mx-auto flex h-[68px] max-w-7xl items-center justify-between px-5 sm:px-8">
          <a href="#inicio" className="group flex items-center gap-2.5">
            <span className="grid h-9 w-9 place-items-center rounded-lg border border-brand/40 bg-brand-soft text-brand transition-all duration-300 group-hover:shadow-[0_0_20px_rgba(0,229,255,.35)]">
              <Terminal size={16} strokeWidth={2.2} />
            </span>
            <span className="font-display text-[17px] font-bold tracking-wide text-white">
              NEXUS<span className="text-brand">_</span>UNLOCK
              <span className="ml-2 hidden font-mono text-[9px] font-normal tracking-[0.3em] text-white/35 sm:inline">LAB</span>
            </span>
          </a>

          <nav className="hidden items-center gap-7 lg:flex">
            {LINKS.map((l) => (
              <a
                key={l.href}
                href={l.href}
                className={cn(
                  "group relative font-mono text-[11px] tracking-[0.18em] uppercase transition-colors duration-300",
                  active === l.href.slice(1) ? "text-brand" : "text-white/55 hover:text-white"
                )}
              >
                {l.label}
                <span
                  className={cn(
                    "absolute -bottom-2 left-0 h-px bg-brand transition-all duration-300",
                    active === l.href.slice(1) ? "w-full" : "w-0 group-hover:w-full"
                  )}
                />
              </a>
            ))}
          </nav>

          <div className="flex items-center gap-3">
            <a
              href="#contacto"
              className="btn-primary group hidden items-center gap-2 rounded-full bg-brand px-5 py-2.5 font-mono text-[11px] font-semibold tracking-[0.14em] text-[#03181d] uppercase transition-shadow duration-300 hover:shadow-[0_0_30px_rgba(0,229,255,.45)] sm:flex"
            >
              <span className="relative z-[2]">Solicitar</span>
              <ArrowUpRight size={14} className="relative z-[2] transition-transform duration-300 group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
            </a>
            <button
              onClick={() => setOpen(!open)}
              aria-label="Abrir menú"
              className="grid h-10 w-10 place-items-center rounded-lg border border-line text-white/80 lg:hidden"
            >
              {open ? <X size={18} /> : <Menu size={18} />}
            </button>
          </div>
        </div>
      </header>

      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.3 }}
            className="fixed inset-0 z-[78] bg-void/95 backdrop-blur-2xl lg:hidden"
          >
            <div className="flex h-full flex-col justify-center gap-2 px-8 pt-16">
              {LINKS.map((l, i) => (
                <motion.a
                  key={l.href}
                  href={l.href}
                  onClick={() => setOpen(false)}
                  initial={{ opacity: 0, x: -24 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.06 * i, duration: 0.5, ease: [0.22, 0.9, 0.24, 1] }}
                  className="group flex items-baseline gap-4 border-b border-line py-5"
                >
                  <span className="font-mono text-[11px] text-brand">0{i + 1}</span>
                  <span className="font-display text-3xl font-bold text-white/85 transition-colors group-hover:text-brand">
                    {l.label}
                  </span>
                </motion.a>
              ))}
              <motion.a
                href="#contacto"
                onClick={() => setOpen(false)}
                initial={{ opacity: 0, y: 16 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.4 }}
                className="mt-8 flex items-center justify-center gap-2 rounded-full bg-brand py-4 font-mono text-xs font-bold tracking-[0.2em] text-[#03181d] uppercase"
              >
                Solicitar desbloqueo <ArrowUpRight size={16} />
              </motion.a>
              <p className="mt-6 text-center font-mono text-[10px] tracking-[0.3em] text-white/30 uppercase">
                PS4 → 13.52 · PS5 → 13.60
              </p>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
