import { type MouseEvent } from "react";
import {
  ArrowUpRight,
  Dices,
  Fan,
  HardDriveDownload,
  Cpu,
  MessagesSquare,
  ShieldCheck,
  type LucideIcon,
} from "lucide-react";
import SectionHeader from "./SectionHeader";
import { Reveal } from "./fx/Reveal";

type Service = {
  icon: LucideIcon;
  title: string;
  desc: string;
  chips: string[];
};

const SERVICES: Service[] = [
  {
    icon: Cpu,
    title: "Panel de inicio completo",
    desc: "Menú propio para gestionar aplicaciones y utilidades desde tu consola, con la misma fluidez del sistema oficial.",
    chips: ["Homebrew", "Emuladores", "File Manager"],
  },
  {
    icon: ShieldCheck,
    title: "Escudo anti-actualizaciones",
    desc: "Bloqueamos las descargas automáticas que anularían el trabajo. Tú decides cuándo y cómo actualizar.",
    chips: ["Permanente", "Reversible", "Sin sustos"],
  },
  {
    icon: HardDriveDownload,
    title: "Gestión de juegos y respaldos",
    desc: "Organiza, respalda y administra tu biblioteca personal con herramientas avanzadas y disco externo.",
    chips: ["Backups", "USB externo", "Biblioteca"],
  },
  {
    icon: Dices,
    title: "Homebrew + emuladores",
    desc: "Pack curado por nuestro equipo: emuladores retro, reproductores multimedia y utilidades de sistema.",
    chips: ["Retro", "Media", "Utils"],
  },
  {
    icon: Fan,
    title: "Optimización térmica",
    desc: "Limpieza profunda y pasta térmica premium incluidas en planes Pro y Elite. Tu consola rinde fresca y silenciosa.",
    chips: ["Pasta premium", "Limpieza", "Pruebas"],
  },
  {
    icon: MessagesSquare,
    title: "Soporte humano directo",
    desc: "Hablas con el técnico que trabajó tu unidad, no con un bot. Antes, durante y después del servicio.",
    chips: ["WhatsApp", "12 meses", "Post-servicio"],
  },
];

function onMoveGlow(e: MouseEvent<HTMLElement>) {
  const el = e.currentTarget;
  const r = el.getBoundingClientRect();
  el.style.setProperty("--mx", `${e.clientX - r.left}px`);
  el.style.setProperty("--my", `${e.clientY - r.top}px`);
}

export default function Services() {
  return (
    <section id="servicios" className="relative py-28 sm:py-36">
      <div className="mx-auto max-w-7xl px-5 sm:px-8">
        <SectionHeader
          index="01"
          label="Qué incluye"
          title={
            <>
              El modo oculto,
              <br />
              <span className="grad-text">desempaquetado.</span>
            </>
          }
          desc="Nada de trucos de una tarde. Instalamos un entorno completo, verificado y pensado para durar años, no semanas."
        />

        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3 sm:gap-5">
          {SERVICES.map((s, i) => (
            <Reveal key={s.title} delay={(i % 3) * 90}>
              <article
                onMouseMove={onMoveGlow}
                className="glow-card group relative flex h-full min-h-[300px] flex-col rounded-2xl border border-line bg-panel/70 p-7 transition-all duration-500 hover:-translate-y-1.5 hover:border-brand/35"
              >
                <div className="mb-8 flex items-start justify-between">
                  <span className="grid h-12 w-12 place-items-center rounded-xl border border-brand/25 bg-brand-soft/50 text-brand transition-all duration-500 group-hover:shadow-[0_0_24px_rgba(0,229,255,.3)]">
                    <s.icon size={20} strokeWidth={1.8} />
                  </span>
                  <span className="font-mono text-[10px] tracking-[0.3em] text-white/25 transition-colors duration-300 group-hover:text-brand/70">
                    /0{i + 1}
                  </span>
                </div>

                <h3 className="font-display text-xl font-bold text-white">{s.title}</h3>
                <p className="mt-3 flex-1 text-[13.5px] leading-relaxed text-white/50">{s.desc}</p>

                <div className="mt-7 flex items-center justify-between gap-2 border-t border-line pt-5">
                  <div className="flex flex-wrap gap-1.5">
                    {s.chips.map((c) => (
                      <span key={c} className="rounded-full border border-white/10 px-2.5 py-1 font-mono text-[9px] tracking-[0.12em] text-white/45 uppercase transition-colors group-hover:border-brand/25 group-hover:text-white/70">
                        {c}
                      </span>
                    ))}
                  </div>
                  <ArrowUpRight
                    size={15}
                    className="shrink-0 text-white/20 transition-all duration-300 group-hover:translate-x-0.5 group-hover:-translate-y-0.5 group-hover:text-brand"
                  />
                </div>
              </article>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
