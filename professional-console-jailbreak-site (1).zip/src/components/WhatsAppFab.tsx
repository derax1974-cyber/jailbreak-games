import { useEffect, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { MessageCircle } from "lucide-react";
import { WA_DEFAULT } from "../lib/site";

export default function WhatsAppFab() {
  const [show, setShow] = useState(false);

  useEffect(() => {
    const onScroll = () => setShow(window.scrollY > 640);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <AnimatePresence>
      {show && (
        <motion.a
          href={WA_DEFAULT}
          target="_blank"
          rel="noreferrer"
          aria-label="Contactar por WhatsApp"
          initial={{ opacity: 0, scale: 0.6, y: 16 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.6, y: 16 }}
          transition={{ duration: 0.35, ease: [0.22, 0.9, 0.24, 1] }}
          className="group fixed right-5 bottom-5 z-[74] flex items-center gap-0 rounded-full bg-brand p-4 text-[#03222a] shadow-[0_10px_36px_rgba(0,229,255,.35)] transition-all duration-300 hover:shadow-[0_10px_48px_rgba(0,229,255,.6)] sm:right-7 sm:bottom-7"
        >
          <span className="absolute top-1 right-1 h-2.5 w-2.5">
            <span className="pulse-dot absolute inline-flex h-full w-full rounded-full bg-[#03222a]" />
          </span>
          <MessageCircle size={20} fill="currentColor" />
          <span className="max-w-0 overflow-hidden font-display text-[11px] font-bold tracking-[0.1em] whitespace-nowrap uppercase transition-all duration-400 group-hover:ml-2.5 group-hover:max-w-[120px]">
            Escríbenos
          </span>
        </motion.a>
      )}
    </AnimatePresence>
  );
}
