import { Check, Crown, FileVideo2, Headset, Rocket, ShieldCheck, Sparkles } from "lucide-react";
import { cn } from "../utils/cn";
import SectionHeader from "./SectionHeader";
import { Reveal } from "./fx/Reveal";
import { waLink } from "../lib/site";

type Plan = {
  name: string;
  tag: string;
  price: number;
  desc: string;
  features: string[];
  featured?: boolean;
};

const PLANS: Plan[] = [
  {
    name: "Esencial",
    tag: "entrada",
    price: 89,
    desc: "El desbloqueo limpio y garantizado, sin extras que no necesitas.",
    features: [
      "Verificación completa de consola",
      "Habilitación del panel de inicio",
      "Escudo anti-actualizaciones",
      "Prueba de estabilidad 24h",
      "Manual post-servicio en PDF",
      "Garantía escrita 3 meses",
    ],
  },
  {
    name: "Pro",
    tag: "el más elegido",
    price: 149,
    desc: "El equilibrio perfecto: consola liberada, optimizada y con todo instalado.",
    features: [
      "Todo lo del plan Esencial",
      "Homebrew Pack Pro (emuladores + apps)",
      "Optimización térmica (limpieza + pasta premium)",
      "Configuración de disco externo",
      "Diagnóstico anual gratuito",
      "Soporte prioritario 12 meses",
    ],
    featured: true,
  },
  {
    name: "Elite",
    tag: "premium",
    price: 229,
    desc: "La experiencia completa, con prioridad absoluta y protección extendida.",
    features: [
      "Todo lo del plan Pro",
      "Multi-Homebrew personalizado a tu gusto",
      "Garantía extendida 24 meses",
      "Canal directo prioridad A",
      "Video-evidencia HD de todo el proceso",
      "Revisión y mantenimiento semestral",
    ],
  },
];

const TRUST = [
  { icon: ShieldCheck, text: "Garantía escrita con número de unidad" },
  { icon: FileVideo2, text: "Evidencia en video antes de pagar" },
  { icon: Headset, text: "Soporte humano, no bots" },
];

export default function Pricing() {
  return (
    <section id="planes" className="relative py-28 sm:py-36">
      <div className="pointer-events-none absolute top-1/3 left-1/2 h-[520px] w-[720px] -translate-x-1/2 rounded-full bg-brand/[0.05] blur-[130px]" />
      <div className="mx-auto max-w-7xl px-5 sm:px-8">
        <SectionHeader
          index="03"
          label="Inversión"
          align="center"
          title={
            <>
              Un pago. <span className="grad-text">Una consola nueva.</span>
            </>
          }
          desc="Precios claros por unidad, sin sorpresas. La misma garantía de procedimiento en cada plan: lo que cambia es cuánto poder extra te llevas."
        />

        <div className="grid items-stretch gap-5 md:grid-cols-3 lg:gap-6">
          {PLANS.map((plan, i) => {
            const link = waLink(`Hola NEXUS, me interesa el plan ${plan.name} ($${plan.price}) para mi consola.`);
            return (
              <Reveal key={plan.name} delay={i * 110} className={cn(plan.featured && "md:-translate-y-3")}>
                <article
                  className={cn(
                    "relative flex h-full flex-col rounded-3xl p-7 transition-all duration-500 sm:p-8",
                    plan.featured
                      ? "g-border shadow-[0_18px_70px_rgba(0,229,255,.12)]"
                      : "border border-line bg-panel/70 hover:border-white/20"
                  )}
                >
                  {plan.featured && (
                    <span className="absolute -top-3.5 left-1/2 flex -translate-x-1/2 items-center gap-1.5 rounded-full bg-gradient-to-r from-brand to-violet px-4 py-1.5 font-mono text-[9.5px] font-bold tracking-[0.2em] text-[#041318] uppercase">
                      <Crown size={11} fill="currentColor" /> {plan.tag}
                    </span>
                  )}

                  <div className="mb-6 flex items-center justify-between">
                    <span className={cn("font-mono text-[10.5px] tracking-[0.3em] uppercase", plan.featured ? "text-brand" : "text-white/40")}>
                      plan_{plan.name.toLowerCase()}
                    </span>
                    {plan.featured ? (
                      <Sparkles size={16} className="text-brand" />
                    ) : (
                      <Rocket size={16} className="text-white/25" />
                    )}
                  </div>

                  <h3 className="font-display text-2xl font-bold text-white">{plan.name}</h3>
                  <div className="mt-3 flex items-end gap-2">
                    <span className={cn("font-display text-[52px] leading-none font-bold text-white", plan.featured && "grad-text")}>
                      ${plan.price}
                    </span>
                    <span className="mb-1.5 font-mono text-[10px] tracking-[0.16em] text-white/35 uppercase">/ consola · único</span>
                  </div>
                  <p className="mt-4 text-[13px] leading-relaxed text-white/50">{plan.desc}</p>

                  <ul className="mt-7 mb-8 flex-1 space-y-3 border-t border-line pt-6">
                    {plan.features.map((f) => (
                      <li key={f} className="flex items-start gap-3 text-[13px] text-white/65">
                        <Check size={15} strokeWidth={2.5} className={cn("mt-0.5 shrink-0", plan.featured ? "text-brand" : "text-emerald-400/80")} />
                        {f}
                      </li>
                    ))}
                  </ul>

                  <a
                    href={link}
                    target="_blank"
                    rel="noreferrer"
                    className={cn(
                      "btn-primary group flex items-center justify-center gap-2 rounded-full py-4 font-display text-[12px] font-bold tracking-[0.1em] uppercase transition-all duration-300",
                      plan.featured
                        ? "bg-brand text-[#03222a] hover:shadow-[0_0_36px_rgba(0,229,255,.5)]"
                        : "border border-white/15 text-white hover:border-brand/60 hover:text-brand"
                    )}
                  >
                    <span className="relative z-[2]">Empezar con {plan.name}</span>
                  </a>
                </article>
              </Reveal>
            );
          })}
        </div>

        <Reveal delay={200}>
          <div className="mt-12 flex flex-wrap items-center justify-center gap-x-10 gap-y-4">
            {TRUST.map((t) => (
              <span key={t.text} className="flex items-center gap-2.5 text-[12.5px] text-white/50">
                <t.icon size={15} className="text-brand" />
                {t.text}
              </span>
            ))}
          </div>
        </Reveal>
      </div>
    </section>
  );
}
