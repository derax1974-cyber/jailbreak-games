import { useMemo, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import {
  AlertTriangle,
  ArrowUpRight,
  BadgeCheck,
  CheckCircle2,
  MonitorSmartphone,
  Settings2,
  XCircle,
} from "lucide-react";
import { cn } from "../utils/cn";
import SectionHeader from "./SectionHeader";
import { Reveal } from "./fx/Reveal";
import { waLink } from "../lib/site";

type ConsoleKey = "PS4" | "PS5";

const CONSOLES: Record<
  ConsoleKey,
  { max: number; img: string; alt: string; models: string; defaultV: number }
> = {
  PS4: {
    max: 13.52,
    img: "/img/ps4-console.jpg",
    alt: "PlayStation 4 en laboratorio",
    models: "Fat · Slim · Pro",
    defaultV: 13.0,
  },
  PS5: {
    max: 13.6,
    img: "/img/ps5-console.jpg",
    alt: "PlayStation 5 en laboratorio",
    models: "Fat · Slim · Pro",
    defaultV: 13.2,
  },
};

const TICKS = [12.0, 12.5, 12.52, 13.0, 13.02, 13.5, 13.52, 13.6];

export default function Compatibility() {
  const [consoleKey, setConsoleKey] = useState<ConsoleKey>("PS4");
  const [version, setVersion] = useState<number>(CONSOLES.PS4.defaultV);

  const conf = CONSOLES[consoleKey];
  const eligible = version <= conf.max + 0.0001;

  const select = (k: ConsoleKey) => {
    setConsoleKey(k);
    setVersion(CONSOLES[k].defaultV);
  };

  const result = useMemo(() => {
    if (eligible)
      return waLink(
        `Hola NEXUS, verifiqué mi ${consoleKey} en firmware ${version.toFixed(2)} y es elegible. Quiero agendar el diagnóstico gratuito.`
      );
    return waLink(
      `Hola NEXUS, mi ${consoleKey} está en firmware ${version.toFixed(2)} y quedó fuera de rango. Avísenme cuando haya método estable.`
    );
  }, [eligible, consoleKey, version]);

  const pct = ((version - 12) / (13.6 - 12)) * 100;
  const maxPct = ((conf.max - 12) / (13.6 - 12)) * 100;

  return (
    <section id="compatibilidad" className="relative py-28 sm:py-36">
      <div className="pointer-events-none absolute top-40 -left-32 h-[420px] w-[420px] rounded-full bg-brand/[0.06] blur-[120px]" />
      <div className="mx-auto max-w-7xl px-5 sm:px-8">
        <SectionHeader
          index="00"
          label="Verificador en vivo"
          title={
            <>
              ¿Tu consola es elegible?
              <br />
              <span className="grad-text">Compruébalo en 10 segundos.</span>
            </>
          }
          desc="Selecciona tu modelo y arrastra el firmware. Sin correos, sin esperas: resultado inmediato y honesto."
        />

        <div className="grid items-start gap-10 lg:grid-cols-[0.85fr_1.15fr] lg:gap-14">
          {/* ------- left: how to find version ------- */}
          <div className="space-y-6">
            <Reveal>
              <div className="rounded-2xl border border-line bg-panel/70 p-6 sm:p-7">
                <p className="mb-5 flex items-center gap-2.5 font-mono text-[10.5px] tracking-[0.3em] text-brand uppercase">
                  <MonitorSmartphone size={15} /> ¿Dónde veo mi versión?
                </p>
                <ol className="space-y-4">
                  {[
                    "Enciende tu consola y entra a Ajustes.",
                    "Ve a Consola / Sistema → Información de la consola.",
                    "Busca la línea «Versión de software de sistema».",
                    "Anota el número completo (ej. 13.52) y úsalo en el verificador.",
                  ].map((t, i) => (
                    <li key={i} className="flex gap-4 text-[13.5px] leading-relaxed text-white/55">
                      <span className="font-mono text-[11px] text-brand">{String(i + 1).padStart(2, "0")}</span>
                      {t}
                    </li>
                  ))}
                </ol>
              </div>
            </Reveal>
            <Reveal delay={120}>
              <div className="flex items-start gap-3 rounded-2xl border border-emerald-400/20 bg-emerald-400/[0.05] p-5">
                <BadgeCheck size={17} className="mt-0.5 shrink-0 text-emerald-400" />
                <p className="text-[13px] leading-relaxed text-white/60">
                  <span className="font-semibold text-emerald-300">Promesa NEXUS:</span> si tu unidad no es viable hoy,
                  te lo decimos gratis y te registramos para avisarte. Cero humo, cero presión de venta.
                </p>
              </div>
            </Reveal>
            <Reveal delay={200}>
              <div className="flex items-start gap-3 rounded-2xl border border-line bg-panel/50 p-5">
                <Settings2 size={16} className="mt-0.5 shrink-0 text-brand" />
                <p className="font-mono text-[10.5px] leading-relaxed tracking-[0.08em] text-white/35 uppercase">
                  Verificador orientativo — placa y serial se confirman en el diagnóstico gratuito
                </p>
              </div>
            </Reveal>
          </div>

          {/* ------- right: interactive ------- */}
          <Reveal delay={100} className="g-border rounded-3xl">
            <div className="rounded-3xl p-6 sm:p-8">
              {/* console select */}
              <p className="mb-4 font-mono text-[10px] tracking-[0.32em] text-white/40 uppercase">01 · Elige tu consola</p>
              <div className="grid grid-cols-2 gap-3 sm:gap-4">
                {(Object.keys(CONSOLES) as ConsoleKey[]).map((k) => {
                  const c = CONSOLES[k];
                  const active = consoleKey === k;
                  return (
                    <button
                      key={k}
                      onClick={() => select(k)}
                      className={cn(
                        "group relative overflow-hidden rounded-2xl border text-left transition-all duration-400",
                        active
                          ? "border-brand/70 shadow-[0_0_28px_rgba(0,229,255,.18)]"
                          : "border-line hover:border-white/25"
                      )}
                    >
                      <span className="relative block h-28 overflow-hidden sm:h-32">
                        <img
                          src={c.img}
                          alt={c.alt}
                          className={cn(
                            "h-full w-full object-cover transition-all duration-500",
                            active ? "scale-100 saturate-100" : "scale-105 saturate-[.35] group-hover:saturate-75"
                          )}
                          loading="lazy"
                        />
                        <span className="absolute inset-0 bg-gradient-to-t from-[#05080d] via-[#05080d33] to-transparent" />
                        {active && (
                          <span className="absolute top-2 right-2 grid h-6 w-6 place-items-center rounded-full bg-brand text-[#03222a]">
                            <CheckCircle2 size={14} />
                          </span>
                        )}
                      </span>
                      <span className="relative z-10 flex items-end justify-between p-4">
                        <span>
                          <span className="font-display block text-lg font-bold text-white">{k}</span>
                          <span className="font-mono mt-0.5 block text-[9px] tracking-[0.2em] text-white/40 uppercase">{c.models}</span>
                        </span>
                        <span className={cn("font-mono text-[10.5px] tracking-wider", active ? "text-brand" : "text-white/30")}>
                          ≤ {c.max.toFixed(2)}
                        </span>
                      </span>
                    </button>
                  );
                })}
              </div>

              {/* slider */}
              <p className="mt-8 mb-4 font-mono text-[10px] tracking-[0.32em] text-white/40 uppercase">02 · Arrastra tu firmware</p>
              <div className="rounded-2xl border border-line bg-void/60 px-5 pt-6 pb-4 sm:px-7">
                <div className="relative">
                  <div className="absolute inset-x-0 top-1/2 h-[3px] -translate-y-1/2 rounded-full bg-white/10" />
                  <div
                    className="absolute top-1/2 h-[3px] -translate-y-1/2 rounded-full bg-gradient-to-r from-brand to-violet shadow-[0_0_12px_rgba(0,229,255,.5)]"
                    style={{ width: `${pct}%` }}
                  />
                  {/* threshold marker */}
                  <div
                    className="absolute top-1/2 z-[1] h-6 w-[2px] -translate-y-1/2 bg-emerald-400"
                    style={{ left: `${maxPct}%` }}
                  >
                    <span className="absolute -top-5 left-1/2 -translate-x-1/2 font-mono text-[8.5px] tracking-[0.1em] whitespace-nowrap text-emerald-300">
                      límite {conf.max.toFixed(2)}
                    </span>
                  </div>
                  <input
                    type="range"
                    min={12}
                    max={13.6}
                    step={0.01}
                    value={version}
                    onChange={(e) => setVersion(Number(e.target.value))}
                    aria-label="Versión de firmware"
                    className="relative z-10 h-2 w-full cursor-pointer appearance-none bg-transparent [&::-moz-range-thumb]:h-6 [&::-moz-range-thumb]:w-6 [&::-moz-range-thumb]:cursor-grab [&::-moz-range-thumb]:rounded-full [&::-moz-range-thumb]:border-2 [&::-moz-range-thumb]:border-[#0a2b33] [&::-moz-range-thumb]:bg-brand [&::-moz-range-thumb]:shadow-[0_0_18px_rgba(0,229,255,.8)] [&::-webkit-slider-thumb]:h-6 [&::-webkit-slider-thumb]:w-6 [&::-webkit-slider-thumb]:cursor-grab [&::-webkit-slider-thumb]:appearance-none [&::-webkit-slider-thumb]:rounded-full [&::-webkit-slider-thumb]:border-2 [&::-webkit-slider-thumb]:border-[#0a2b33] [&::-webkit-slider-thumb]:bg-brand [&::-webkit-slider-thumb]:shadow-[0_0_18px_rgba(0,229,255,.9)]"
                  />
                </div>
                <div className="mt-4 flex justify-between">
                  {TICKS.map((t) => (
                    <button
                      key={t}
                      onClick={() => setVersion(t)}
                      className={cn(
                        "font-mono text-[9.5px] tracking-wider transition-colors",
                        Math.abs(version - t) < 0.005 ? "text-brand" : "text-white/25 hover:text-white/60"
                      )}
                    >
                      {t.toFixed(2)}
                    </button>
                  ))}
                </div>
              </div>

              {/* result */}
              <p className="mt-8 mb-4 font-mono text-[10px] tracking-[0.32em] text-white/40 uppercase">03 · Resultado</p>
              <AnimatePresence mode="wait">
                <motion.div
                  key={`${consoleKey}-${eligible}`}
                  initial={{ opacity: 0, y: 14, scale: 0.985 }}
                  animate={{ opacity: 1, y: 0, scale: 1 }}
                  exit={{ opacity: 0, y: -10, scale: 0.985 }}
                  transition={{ duration: 0.45, ease: [0.22, 0.9, 0.24, 1] }}
                  className={cn(
                    "relative overflow-hidden rounded-2xl border p-6 sm:p-7",
                    eligible
                      ? "border-emerald-400/35 bg-emerald-400/[0.06]"
                      : "border-mag/35 bg-mag/[0.05]"
                  )}
                >
                  <div className="flex flex-wrap items-start gap-5">
                    <span
                      className={cn(
                        "grid h-12 w-12 shrink-0 place-items-center rounded-xl border",
                        eligible ? "border-emerald-400/40 text-emerald-300" : "border-mag/40 text-mag"
                      )}
                    >
                      {eligible ? <CheckCircle2 size={22} /> : <XCircle size={22} />}
                    </span>
                    <div className="min-w-[220px] flex-1">
                      <p className="font-display text-xl font-bold tracking-tight text-white sm:text-2xl">
                        {eligible ? "CONSOLA ELEGIBLE — LISTA PARA LIBERAR" : "FUERA DE RANGO — TODAVÍA NO"}
                      </p>
                      <p className="mt-2 max-w-lg text-[13.5px] leading-relaxed text-white/55">
                        {eligible ? (
                          <>
                            Tu {consoleKey} en firmware <span className="font-mono text-white/85">{version.toFixed(2)}</span> está
                            dentro del protocolo {consoleKey} (soportamos hasta{" "}
                            <span className="font-mono text-brand">{conf.max.toFixed(2)}</span>). Agenda el diagnóstico
                            gratuito y confirmamos placa y serial.
                          </>
                        ) : (
                          <>
                            Los firmwares superiores a <span className="font-mono text-brand">{conf.max.toFixed(2)}</span> en{" "}
                            {consoleKey} aún no tienen método estable. No te haremos falsas promesas: te avisamos apenas
                            exista uno verificado.
                          </>
                        )}
                      </p>
                      <div className="mt-5 flex flex-wrap items-center gap-3">
                        <a
                          href={result}
                          target="_blank"
                          rel="noreferrer"
                          className={cn(
                            "btn-primary group inline-flex items-center gap-2 rounded-full px-6 py-3 font-display text-[12px] font-bold tracking-[0.08em] uppercase",
                            eligible ? "bg-emerald-400 text-[#04241a]" : "bg-white/90 text-[#1a0a10]"
                          )}
                        >
                          <span className="relative z-[2] flex items-center gap-2">
                            {eligible ? "Agendar diagnóstico gratis" : "Notificarme cuando esté listo"}
                            <ArrowUpRight size={14} />
                          </span>
                        </a>
                        {eligible ? (
                          <a href="#planes" className="font-mono text-[11px] tracking-[0.14em] text-white/55 uppercase underline-offset-4 transition-colors hover:text-brand hover:underline">
                            ver planes
                          </a>
                        ) : (
                          <span className="flex items-center gap-2 font-mono text-[10px] tracking-[0.14em] text-white/35 uppercase">
                            <AlertTriangle size={12} /> respaldo honesto garantizado
                          </span>
                        )}
                      </div>
                    </div>
                  </div>
                </motion.div>
              </AnimatePresence>
            </div>
          </Reveal>
        </div>
      </div>
    </section>
  );
}
