import { useRef } from "react";
import { motion, useScroll, useSpring } from "framer-motion";
import { ClipboardCheck, FileVideo2, Route, Wrench, type LucideIcon } from "lucide-react";
import SectionHeader from "./SectionHeader";
import { Reveal } from "./fx/Reveal";

type Step = {
  icon: LucideIcon;
  title: string;
  desc: string;
  meta: string[];
};

const STEPS: Step[] = [
  {
    icon: ClipboardCheck,
    title: "Diagnóstico gratuito",
    desc: "Nos envías una foto de tu versión y modelo. Confirmamos placa, serial y compatibilidad real en minutos, con total honestidad: si tu consola no es viable hoy, te lo decimos.",
    meta: ["15 min", "Sin costo", "100% honesto"],
  },
  {
    icon: Route,
    title: "Protocolo y método",
    desc: "Elegimos juntos el método: servicio remoto asistido en vivo, o envío o entrega presencial documentada. Firmas un contrato técnico claro, sin letra pequeña.",
    meta: ["Remoto LATAM", "Presencial cita", "Contrato"],
  },
  {
    icon: Wrench,
    title: "Instalación de precisión",
    desc: "Aplicamos la cadena específica para tu placa y firmware. Respaldo previo de tus datos (opcional) y registro de cada paso en fotos y logs.",
    meta: ["90–150 min", "Logs registrados", "Backup opcional"],
  },
  {
    icon: FileVideo2,
    title: "Entrega con evidencia",
    desc: "Tres pruebas de arranque consecutivas, video HD del funcionamiento, manual post-servicio en PDF y garantía escrita de 12 meses con tu número de unidad.",
    meta: ["Video HD", "Manual PDF", "Garantía 12M"],
  },
];

export default function Process() {
  const listRef = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({
    target: listRef,
    offset: ["start 0.72", "end 0.55"],
  });
  const scaleY = useSpring(scrollYProgress, { stiffness: 90, damping: 24 });

  return (
    <section id="proceso" className="relative py-28 sm:py-36">
      <div className="pointer-events-none absolute top-20 right-0 h-[380px] w-[380px] rounded-full bg-violet/[0.07] blur-[110px]" />
      <div className="mx-auto max-w-7xl px-5 sm:px-8">
        <SectionHeader
          index="02"
          label="Cómo trabajamos"
          title={
            <>
              Un método. Cuatro pasos.
              <br />
              <span className="text-stroke">Cero sorpresas.</span>
            </>
          }
          desc="El mismo protocolo documentado en más de 2,500 consolas. Así se trabaja cuando el resultado es tu reputación."
        />

        <div ref={listRef} className="relative ml-2 sm:ml-8">
          {/* progress spine */}
          <div className="absolute top-2 bottom-8 left-[27px] w-px bg-line sm:left-[43px]" />
          <motion.div
            style={{ scaleY }}
            className="absolute top-2 bottom-8 left-[27px] w-px origin-top bg-gradient-to-b from-brand via-violet to-brand shadow-[0_0_12px_rgba(0,229,255,.6)] sm:left-[43px]"
          />

          <div className="flex flex-col gap-14 sm:gap-16">
            {STEPS.map((step, i) => (
              <Reveal key={step.title} delay={i * 60}>
                <div className="relative grid grid-cols-[56px_1fr] items-start gap-5 sm:grid-cols-[88px_1fr] sm:gap-10">
                  <div className="relative z-10 grid h-[56px] w-[56px] place-items-center rounded-full border border-brand/30 bg-void font-display text-lg font-bold text-brand shadow-[0_0_0_8px_rgba(5,7,12,1)] sm:h-[88px] sm:w-[88px] sm:text-2xl">
                    0{i + 1}
                  </div>
                  <article className="group glow-card overflow-hidden rounded-2xl border border-line bg-panel/60 p-6 transition-all duration-500 hover:border-brand/30 sm:p-8">
                    <div className="flex flex-wrap items-center justify-between gap-3">
                      <h3 className="font-display flex items-center gap-3 text-xl font-bold text-white sm:text-2xl">
                        <step.icon size={19} className="text-brand" strokeWidth={1.8} />
                        {step.title}
                      </h3>
                      <span className="font-mono text-[9.5px] tracking-[0.28em] text-white/25 uppercase">
                        fase_0{i + 1}
                      </span>
                    </div>
                    <p className="mt-3 max-w-2xl text-[14px] leading-relaxed text-white/50">{step.desc}</p>
                    <div className="mt-5 flex flex-wrap gap-2">
                      {step.meta.map((m) => (
                        <span key={m} className="rounded-md border border-brand/20 bg-brand-soft/40 px-2.5 py-1 font-mono text-[9.5px] tracking-[0.14em] text-brand/90 uppercase">
                          {m}
                        </span>
                      ))}
                    </div>
                  </article>
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
