import { Clock, Globe, Mail, MessageCircle, Send, Zap } from "lucide-react";
import { Reveal } from "./fx/Reveal";
import { CONTACT, WA_DEFAULT } from "../lib/site";

const INFO = [
  { icon: MessageCircle, label: "WhatsApp directo", value: CONTACT.whatsappDisplay, href: WA_DEFAULT },
  { icon: Mail, label: "Correo", value: CONTACT.email, href: `mailto:${CONTACT.email}` },
  { icon: Clock, label: "Horario de laboratorio", value: CONTACT.hours },
  { icon: Globe, label: "Cobertura", value: CONTACT.coverage },
];

export default function Contact() {
  return (
    <section id="contacto" className="relative overflow-hidden pt-28 pb-24 sm:pt-36">
      <div className="pointer-events-none absolute top-0 left-1/2 h-[420px] w-[900px] -translate-x-1/2 rounded-full bg-brand/[0.08] blur-[140px]" />

      <div className="relative mx-auto max-w-5xl px-5 text-center sm:px-8">
        <Reveal>
          <p className="kicker mb-6">[ 06 ] — Iniciar protocolo</p>
        </Reveal>
        <Reveal delay={90}>
          <h2 className="font-display text-[clamp(2.6rem,7vw,5rem)] leading-[1.0] font-bold tracking-tight text-white">
            ¿Listo para el
            <br />
            <span className="text-stroke">MODO OCULTO</span>
            <span className="grad-text">?</span>
          </h2>
        </Reveal>
        <Reveal delay={180}>
          <p className="mx-auto mt-6 max-w-xl text-[15px] leading-relaxed text-white/50">
            Escríbenos con la versión de tu firmware y recibe el diagnóstico gratuito en menos de 15 minutos.
            Si tu consola califica, tu cita queda apartada hoy mismo.
          </p>
        </Reveal>

        <Reveal delay={260}>
          <div className="mt-10 flex flex-wrap items-center justify-center gap-4">
            <a
              href={WA_DEFAULT}
              target="_blank"
              rel="noreferrer"
              className="btn-primary group inline-flex items-center gap-3 rounded-full bg-brand px-8 py-4.5 font-display text-[13px] font-bold tracking-[0.08em] text-[#03222a] uppercase transition-all duration-300 hover:shadow-[0_0_50px_rgba(0,229,255,.55)]"
            >
              <span className="relative z-[2] flex items-center gap-3">
                <MessageCircle size={16} fill="currentColor" className="text-[#03222a]" />
                Escribir por WhatsApp
                <Zap size={15} fill="currentColor" />
              </span>
            </a>
            <a
              href={`mailto:${CONTACT.email}`}
              className="inline-flex items-center gap-2.5 rounded-full border border-white/15 px-8 py-4.5 font-display text-[13px] font-semibold tracking-[0.08em] text-white/85 uppercase transition-all duration-300 hover:border-brand/60 hover:text-brand"
            >
              <Send size={15} className="text-brand" />
              Enviar correo
            </a>
          </div>
        </Reveal>

        <Reveal delay={330}>
          <p className="mt-8 font-mono text-[10.5px] tracking-[0.24em] text-white/30 uppercase">
            respuesta_promedio: <span className="text-brand">4m 32s</span> · diagnóstico: <span className="text-emerald-400">gratuito</span>
          </p>
        </Reveal>

        <Reveal delay={400}>
          <div className="mx-auto mt-16 grid max-w-4xl gap-px overflow-hidden rounded-2xl border border-line bg-line sm:grid-cols-2 lg:grid-cols-4">
            {INFO.map((item) => {
              const inner = (
                <div className="group flex h-full flex-col items-start gap-2 bg-panel/90 p-6 text-left transition-colors duration-300 hover:bg-panel2">
                  <item.icon size={17} className="text-brand" />
                  <span className="font-mono text-[9.5px] tracking-[0.26em] text-white/35 uppercase">{item.label}</span>
                  <span className="font-display text-[14px] leading-snug font-semibold break-all text-white/85">{item.value}</span>
                </div>
              );
              return item.href ? (
                <a key={item.label} href={item.href} target="_blank" rel="noreferrer">
                  {inner}
                </a>
              ) : (
                <div key={item.label}>{inner}</div>
              );
            })}
          </div>
        </Reveal>
      </div>
    </section>
  );
}
